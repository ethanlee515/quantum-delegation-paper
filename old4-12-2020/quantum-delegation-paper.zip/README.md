# quantum-delegation-paper

This is a paper in progress being written in Academia Sinica.
